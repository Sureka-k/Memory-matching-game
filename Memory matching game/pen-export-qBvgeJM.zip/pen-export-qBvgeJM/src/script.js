const levels = [
    { rows: 2, columns: 2, symbols: ['😀', '😎'], message: 'Level 1: Match the emojis!', winMessage: 'Congratulations! You completed Level 1' },
    { rows: 3, columns: 2, symbols: ['😀', '😎', '😊'], message: 'Level 2: Match the emojis!', winMessage: 'Congratulations! You completed Level 2!' },
    { rows: 4, columns: 2, symbols: ['😀', '😎', '😊', '🤔'], message: 'Level 3: Match the emojis!', winMessage: 'Congratulations! You completed Level 3!' },
    { rows: 4, columns: 3, symbols: ['😀', '😎', '😊', '🤔', '😍', '🤩'], message: 'Level 4: Match the emojis!', winMessage: 'Congratulations! You completed Level 4!' },
    { rows: 4, columns: 4, symbols: ['😀', '😎', '😊', '🤔', '😍', '🤩', '😉','🤓'], message: 'Level 5: Match the emojis!', winMessage: 'Congratulations! You completed Level 5!' },
    { rows: 5, columns: 4, symbols: ['😀', '😎', '😊','🥶','😈','👹','🤡','👻','🤖','🥸'], message: 'Level 6: Match the emojis within 1 minute!', winMessage: 'Congratulations! You completed Level 6!' , timeLimit: 60}, 
    { rows: 5, columns: 6, symbols: ['😀', '😎', '😊','🥶','😈','👹','🤡','👻','🤖','🥸','🫠','🤩','😴','🤖','👽'], message: 'Level 7: Match the emojis within 1 minute 30 seconds!', winMessage: 'Congratulations! You completed Level 7!' , timeLimit: 90},
    { rows: 6, columns: 6, symbols: ['😀', '😎', '😊','🥶','😈','👹','🤡','👻','🤖','🥸','🫠','🤩','😴','🤖','👽','🥺','😪','🤥'], message: 'Level 8: Match the emojis within 3 minute!', winMessage: 'Congratulations! You completed Level 8!' , timeLimit: 180},
    { rows: 6, columns: 8, symbols: ['😀', '😎', '😊','🥶','😈','👹','🤡','👻','🤖','🥸','🫠','🤩','😴','🤖','👽','🥺','😪','🤥','🫡','🤠','😤','🥴','😭','🧐'], message: 'Level 9: Match the emojis within 3 minute 30 seconds!', winMessage: 'Congratulations! You completed Level 9!' , timeLimit: 210},
    { rows: 8, columns: 8, symbols: ['😀', '😎', '😊','🥶','😈','👹','🤡','👻','🤖','🥸','🫠','🤩','😴','🤖','👽','🥺','😪','🤥','🫡','🤠','😤','🥴','😭','🧐','😍','🥰','😘','🫶','🫦','🫰','🧚‍♀️','🤴'], message: 'Level 10: Match the emojis within 4 minute!', winMessage: 'Congratulations! You completed Level 10!', timeLimit: 240}
];
let currentLevel = 0;
let cards = [];
let flippedCards = [];
let matchedCards = [];
let gameActive = true;
let timer;

const gameBoard = document.getElementById('gameBoard');
const statusDisplay = document.getElementById('status');
const landingPage = document.getElementById('landingPage');
const levelPage = document.getElementById('level1Page');

function initializeLevel(level) {
    const { rows, columns, symbols } = levels[level];
    cards = [...symbols, ...symbols].sort(() => Math.random() - 0.5);
    const numCards = rows * columns;
    cards = cards.slice(0, numCards);
}

function startLevel(level) {
    initializeLevel(level);
    renderCards();
    statusDisplay.innerText = levels[level].message;
    if (levels[level].timeLimit) {
        startTimer(levels[level].timeLimit);
    }
}

function createCard(symbol, index) {
    const card = document.createElement('div');
    card.classList.add('card');
    card.dataset.index = index;
    card.innerHTML = `
        <div class="card-front"></div>
        <div class="card-back">${symbol}</div>`;
    card.addEventListener('click', flipCard);
    return card;
}

function renderCards() {
    gameBoard.innerHTML = '';
    const { rows, columns } = levels[currentLevel];
    const totalCards = rows * columns;

    for (let i = 0; i < rows; i++) {
        const row = document.createElement('div');
        row.classList.add('card-row');
        for (let j = 0; j < columns; j++) {
            const index = i * columns + j;
            if (index < totalCards) {
                const symbol = cards[index];
                const card = createCard(symbol, index);
                row.appendChild(card);
            }
        }
        gameBoard.appendChild(row);
    }
}

function flipCard() {
    if (!gameActive || flippedCards.length === 2 || this.classList.contains('card-flipped')) return;

    this.classList.add('card-flipped');
    flippedCards.push(this);

    if (flippedCards.length === 2) {
        setTimeout(checkForMatch, 1000);
    }
}

function checkForMatch() {
    const [card1, card2] = flippedCards;
    const index1 = parseInt(card1.dataset.index);
    const index2 = parseInt(card2.dataset.index);

    if (cards[index1] === cards[index2]) {
        matchedCards.push(card1, card2);
        if (matchedCards.length === cards.length) {
            levelCompleted();
        }
    } else {
        card1.classList.remove('card-flipped');
        card2.classList.remove('card-flipped');
    }
    flippedCards = [];
}

function levelCompleted() {
    statusDisplay.innerText = levels[currentLevel].winMessage;
    gameActive = false;
    if (currentLevel < levels.length - 1) {
        currentLevel++;
        setTimeout(startNextLevel, 2000); // Delay starting the next level to display the win message
    } else {
        setTimeout(endGame, 2000); // Delay ending the game to display the win message
    }
    stopTimer();
}

function startNextLevel() {
    gameActive = true;
    matchedCards = [];
    startLevel(currentLevel);
}

function endGame() {
    const popup = document.getElementById('popup');
    const popupText = document.getElementById('popupText');
    popupText.innerText = 'Congratulations! You completed all levels!';
    popup.style.display = 'block';
}

function resetGame() {
    currentLevel = 0;
    gameActive = true;
    matchedCards = [];
    statusDisplay.innerText = '';
    startLevel(currentLevel);
}

document.getElementById('resetBtn').addEventListener('click', resetGame);

document.getElementById('popupCloseBtn').addEventListener('click', function() {
    document.getElementById('popup').style.display = 'none';
});

function startTimer(timeLimit) {
    let timeLeft = timeLimit;
    updateTimerDisplay(timeLeft);
    timer = setInterval(() => {
        timeLeft--;
        updateTimerDisplay(timeLeft);
        if (timeLeft === 0) {
            stopTimer();
            endGameDueToTimeOut();
        }
    }, 1000);
}

function stopTimer() {
    clearInterval(timer);
}

function updateTimerDisplay(timeLeft) {
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;
    const formattedTime = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    statusDisplay.innerText = `Time Left: ${formattedTime}`;
}

function endGameDueToTimeOut() {
    statusDisplay.innerText = 'Time\'s up! Game Over!';
    gameActive = false;
}

startLevel(currentLevel);

// Add event listener for the "Try Again" button in the time up popup
document.getElementById('tryAgainBtn').addEventListener('click', function() {
    document.getElementById('timeUpPopup').style.display = 'none';
    resetGame();
});

function endGameDueToTimeOut() {
    // Display the time up popup
    document.getElementById('timeUpPopup').style.display = 'block';
    gameActive = false; // Set gameActive to false
}

// Event listener for the "Start Game" button on the landing page
document.getElementById('startBtn').addEventListener('click', function() {
    landingPage.style.display = 'none'; // Hide the landing page
    levelPage.style.display = 'block'; // Show the level page
    startLevel(currentLevel); // Start the game
});